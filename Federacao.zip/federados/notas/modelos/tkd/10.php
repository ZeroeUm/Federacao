<?php
/* 2013-02-01
 * @author Humberto
 */
?>
<table class="table table-condensed table-hover table-bordered">
    <thead>
        <tr>
            <th class="span4">Nome</th>
            <th class="span1">PS</th>
            <th class="span1">PE 1</th>
            <th class="span1">PE 2</th>
            <th class="span1">TG 1</th>
            <th class="span1">TG 2</th>
            <th class="span1">TG 3</th>
            <th class="span1">TG 4</th>
            <th class="span1">TG 5</th>
            <th class="span1">TG 6</th>
            <th class="span1">KD</th>
            <th class="span1">MK 1</th>
            <th class="span1">MK 2</th>
            <th class="span1">HK</th>
            <th class="span1">SK</th>
            <th class="span1">JK</th>
            <th class="span1">KE</th>
            <th class="span1">KP</th>
            <th class="span1">SI</th>
            <th class="span1">HI</th>
            <th class="span1">SO</th>
            <th class="span1">JA</th>
            <th class="span1">KI</th>
            <th class="span1">GI</th>
            <th class="span1">SU</th>
            <th class="span1">GU</th>
            <th class="span1">JI</th>
            <th class="span1">YU</th>
            <th class="span1">IR</th>
            <th class="span1">M�dia</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="span4"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
            <td class="span1"><?php echo nbs(2)?></td>
        </tr>
    </tbody>
</table>