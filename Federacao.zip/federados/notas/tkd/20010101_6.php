<?php
/* 2013-02-01
 * @author Humberto
 */
?>
<table class="table table-condensed table-hover table-bordered">
    <thead>
        <tr>
            <th>Nome</th>
            <th>PS</th>
            <th>TG</th>
            <th>MK</th>
            <th>JK</th>
            <th>YU</th>
            <th>IR</th>
            <th>M�dia</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="span4">Aluna Uma</td>
            <td class="span2">8</td>
            <td class="span2">7,5</td>
            <td class="span2">7,5</td>
            <td class="span2">8</td>
            <td class="span2">8</td>
            <td class="span2">7,5</td>
            <td class="span2">7,75</td>
        </tr>
    </tbody>
</table>