todas as notas do aluno
