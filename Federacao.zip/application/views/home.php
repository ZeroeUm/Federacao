
<div class="hero-unit">
  <h1>Tela de teste</h1>
  <p>Tela de teste</p>
  <p>
    <a class="btn btn-primary btn-large">
      Learn more
    </a>
  </p>
</div>