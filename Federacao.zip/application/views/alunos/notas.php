<div class="well">
    <h4>Hist�rico de notas</h4>
</div>
<table class="table table-bordered">
              <thead>
                <tr>
                  <th>Avalia��o</th>
                  <th>Data</th>
                  <th>Categoria</th>
                  <th>Nota</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                 <td>Jud�</td>
                  <td>15-10-2005</td>
                  <td>Faixa Branca</td>
                  <td>8.7</td>
                </tr>
                <tr>
                  <td>Jud�</td>
                  <td>18-08-2006</td>
                  <td>Faixa Amarela</td>
                  <td>8.7</td>
                </tr>
                <tr>
                  <td>Jud�</td>
                  <td>15-05-2007</td>
                  <td>Faixa Azul</td>
                  <td>9.9</td>
                </tr> 
              </tbody>
            </table>