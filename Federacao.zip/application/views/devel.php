<div class="bs-docs-example" style="overflow: hidden;">
            <blockquote class="pull-right">
              <p>Pagina em desenvolvimento</p>
              <small>Falta a cria��o da view</small>
            </blockquote>
          </div>