<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="row-fluid">
    <div class="alert-success">
        Altera��es nas informa��es cadastrais da filial <?php echo $filial ?> realizadas com sucesso.<br />
        <b>
            <?php
            echo anchor('administrador/filiais', 'Clique aqui para voltar � �rea de manuten��o de dados de filiais.');
            ?>
        </b>
    </div>
</div>