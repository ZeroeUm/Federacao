<?php
/*
 * 2013-01-29
 * @author Humberto
 */
?>
<div class="row-fluid">
    <div class="alert-success">
        Inclus�o da filial <?php echo $filial ?> na Federa��o Paulista de Artes Marciais Interestilos realizada com sucesso.<br/>
        <b>
            <?php
            echo anchor('administrador/filiais', 'Clique aqui para voltar � �rea de manuten��o de dados de filiais.');
            ?>
        </b>
    </div>
</div>