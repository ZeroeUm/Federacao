<?php

$lang['scaff_view_records']		= 'Vizualizar Linhas';
$lang['scaff_create_record']	= 'Criar Nova Linha';
$lang['scaff_add']				= 'Adicionar Dados';
$lang['scaff_view']				= 'Vizualizar Dados';
$lang['scaff_edit']				= 'Editar';
$lang['scaff_delete']			= 'Deletar';
$lang['scaff_view_all']			= 'Vizualizar Tudo';
$lang['scaff_yes']				= 'Sim';
$lang['scaff_no']				= 'N�o';
$lang['scaff_no_data']			= 'Nenhum dado existe para esta tabela ainda.';
$lang['scaff_del_confirm']		= 'Voc� tem certeza que deseja excluir a seguinte linha:';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/english/scaffolding_lang.php */